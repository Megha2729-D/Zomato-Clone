import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap/dist/css/bootstrap.css';
// import Home from './Components/home';
import Router from './Components/Router';
// import Router from './Components/route';

// ReactDOM.render(<Router/>, document.getElementById('root'));

ReactDOM.render(<Router/>, document.getElementById('root'));